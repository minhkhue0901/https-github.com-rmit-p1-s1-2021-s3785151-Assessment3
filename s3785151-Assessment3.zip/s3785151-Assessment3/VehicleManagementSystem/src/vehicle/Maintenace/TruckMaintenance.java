package vehicle.Maintenace;

public class TruckMaintenance {

}
