package vehicles.exceptions;

public class IllegalRegistrationExceptions {

}
